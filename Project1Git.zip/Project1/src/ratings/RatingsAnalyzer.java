package ratings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import ratings.ratables.Ratable;
import ratings.ratables.Song;

public class RatingsAnalyzer {

	/*OBJECTIVE 1!
	 * 
	 * The first parameter represents all the ratings for a particular item, the second parameter 
	 *is the number of additional ratings to add, and the third parameter is the value of these additional 
	 *ratings. The return value is the bayesian average of these ratings based on these parameters.
	 */

	public static double bayesianAverage (ArrayList<Double> oR, int aR, double vAR) {
		//oR = Original Ratings
		//aR =  Additional Ratings
		//vAR = Value of the Additional Ratings

		//The new average should equal the old rating plus 5 new ratings of three, over their total amount. 
		//To get the total amount we have to count the amount of ratings in the original, add five
		//and divide our new average it by the new total. 
		double originalTotal = 0.0;
		for(double value: oR) {
			originalTotal += value;
		}
		double numerator = originalTotal + aR * vAR;
		double denominator = oR.size() + aR;
		double bA = numerator/denominator;
		return bA;
		
	}


	public static Song bestSong (ArrayList<Song> a, int b, double c) {
		double max = Double.MIN_VALUE;
		Song maxSong = null;
		for(Song s : a) {
			double newSong = bayesianAverage(s.getRatings(), b, c);
			if(newSong > max) {
				max = newSong;
				maxSong = s;
			}		
		}
		return maxSong;
	}
	
	public static Ratable bestRatable(ArrayList<Ratable> details, int eReviews, double vAR) {
		double max = Double.MIN_VALUE;
		Ratable maxRatable = null;
		for(Ratable s : details) {
			double newRatable = bayesianAverage(s.getRatings(), eReviews, vAR);
			if(newRatable > max) {
				max = newRatable;
				maxRatable = s;
			}		
		}
		return maxRatable;	
}

	@SuppressWarnings("unchecked")
	public static ArrayList<Ratable> getTopK (ArrayList<Ratable>ratable, int k, Comparator<Ratable> comparator){
		ArrayList<Ratable> copy = (ArrayList<Ratable>) ratable.clone();
		Collections.sort(copy, comparator);
		
		while(copy.size() > k) {
			copy.remove(copy.size()-1);
		}
		
		return copy;
	}
	
}


