package ratings;

import java.util.ArrayList;

public class Main {

	public static void main (String[] args) {
		
		
		ArrayList<Double> oR = new ArrayList<Double>();
		oR.add(5.0);
		oR.add(2.0);
		oR.add(3.0);
		oR.add(3.0);
		int aR = 8;
		double vAR= 1.62;
		
		
		System.out.println(RatingsAnalyzer.bayesianAverage(oR, aR, vAR));
		
	}
	
}
