package ratings;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Request;

import com.eclipsesource.json.*;

import ratings.ratables.Product;
import ratings.ratables.Ratable;
import ratings.ratables.Song;

public class DataSources {

	public static ArrayList<Song> readSongCSVFile(String filename){
		ArrayList<Song> songs = new ArrayList<Song>();
		try {
			for(String s:Files.readAllLines(Paths.get(filename))) {
				String [] a = s.split(",");
				Song descriptions = new Song(a[0],a[1],a[2]);
				boolean bool = false;
				for(Song b:songs) {
					if(b.getID().equals(a[0])) {
						b.addRating(Double.parseDouble(a[3]));
						bool = true;
					}

				}
				if(!bool) {
					songs.add(descriptions);
					descriptions.addRating((double)Integer.parseInt(a[3]));
				}

			}

		} catch(IOException e) {
			e.printStackTrace();
			System.out.println("Oops!");
		}
		return songs;
	}

	public static ArrayList<Ratable> readSongsAsRatables(String filename2){
		ArrayList<Ratable> songs = new ArrayList<Ratable>();
		//readSongCSVFile(filename2);
		songs.addAll(readSongCSVFile(filename2));
		return songs;

	}


	public static ArrayList<Ratable> readProductCSVFile(String filename3){
		ArrayList<Ratable> products = new ArrayList<Ratable>();
		try {
			for(String s:Files.readAllLines(Paths.get(filename3))) {
				String [] a = s.split(",");
				Product descriptions = new Product(a[0]);
				boolean bool = false;
				for(Ratable b:products) {
					if(b.getID().equals(a[0])) {
						b.addRating(Double.parseDouble(a[2]));
						bool = true;
					}

				}
				if(!bool) {
					products.add(descriptions);
					descriptions.addRating((double)Integer.parseInt(a[2]));
				}

			}

		} catch(IOException e) {
			e.printStackTrace();
			System.out.println("Oops!");
		}
		return products;

	}

	public static ArrayList<Ratable> getSongsFromAPI(){
		ArrayList<Ratable> retVal = new ArrayList<Ratable>();
		String res = "";
		try {
			res = Request.Get("https://fury.cse.buffalo.edu/api/musicRatings/getAllSongs").execute().returnContent().asString();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			System.out.println("1");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("2");
			e.printStackTrace();
		}
//		System.out.println(res);
		JsonValue value = Json.parse(res);
		JsonArray newArr = value.asArray();
		
		for(JsonValue arrValue: newArr) {
			JsonObject newObject = arrValue.asObject();
			
			String id = newObject.get("youtubeID").asString();
			String title = newObject.get("title").asString();
			String artist = newObject.get("artist").asString();

			Song goodSong = new Song(id, artist, title);
			JsonArray ratings = newObject.get("ratings").asArray();
			for(JsonValue rating: ratings) {
				String jsonVal = rating.toString();
				int rate = Integer.parseInt(jsonVal);
				goodSong.addRating((double)rate);
			}
			retVal.add(goodSong);
		}
//		System.out.println(newArr.get(0).asObject().get("youtubeID").toString());
//		System.out.println(retVal.get(0).getID());
//		boolean check = false;
//		String str = retVal.get(0).getID();
//		for(Ratable s : retVal) {
//			if(((Song)s).getID().equals("L_XJ_s5IsQc")) {
//				System.out.println("yes");
//				check = true;
//			}
//		}
//		if(!check) {
//			System.out.println("no");
//		}
		return retVal;
	}
	

	public static void main(String[] args) {
		getSongsFromAPI();
	}



}


