package ratings.ratables;

import java.util.ArrayList;

public abstract class Ratable {

	
	private ArrayList<Double> rating;
	

	public Ratable() {
		rating  = new ArrayList<Double>();
	}
	
	public abstract String getID();
	public abstract String getLink();
	public abstract String getDescription();
	
	public void addRating (double rating) {
		this.rating.add(rating);
	}
		
	
	public ArrayList<Double> getRatings() {
		return rating;
	}
	

}
