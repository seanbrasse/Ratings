package ratings.ratables;

import java.util.ArrayList;

public class Song extends Ratable{
	private String youtubeID;
	private String artist;
	private String title;

	
	
	public Song (String youtubeID, String artist, String title) {
		
		super();
		
		this.youtubeID = youtubeID;
		this.artist = artist;
		this.title = title;		
	}
	
	//Do not modify any methods below 
	@Override
	public String getID() {
		return youtubeID;
	}
	public String getLink() {
		String url = "https://www.youtube.com/watch?v=" + youtubeID;
		return url;
	}
	
	public String getDescription() {
		String description = artist + " - " + title;
		return description;
	}

	
	
}
