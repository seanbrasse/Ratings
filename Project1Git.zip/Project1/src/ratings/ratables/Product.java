package ratings.ratables;

public class Product extends Ratable{

	private String asin;
	
	public Product(String asin) {
		super();
		this.asin = asin;
	}

	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return asin;
	}

	@Override
	public String getLink() {
		// TODO Auto-generated method stub
		return "https://www.amazon.com/dp/" + asin;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return asin;
	}
}
