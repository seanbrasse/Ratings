package ratings.comparators;

import java.util.Comparator;

import ratings.ratables.Ratable;

public class NumberOfRatingsComparator implements Comparator<Ratable> {

	@Override
	public int compare(Ratable o1, Ratable o2) {
		int a = o1.getRatings().size();
		int b = o2.getRatings().size();
		
		if(b > a) {
			return 1;
		}
		
		if(a > b) {
			return -1;
		}
			
		return 0;
	}
	
}
