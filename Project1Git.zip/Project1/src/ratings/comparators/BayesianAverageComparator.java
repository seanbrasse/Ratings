package ratings.comparators;

import java.util.Comparator;

import ratings.RatingsAnalyzer;
import ratings.ratables.Ratable;

public class BayesianAverageComparator implements Comparator<Ratable> {

	//voR== Value of Ratings
	//eR== Extra Ratings
	private double vOR;
	private int eR;

	public BayesianAverageComparator(int eR, double vOR) {
		this.vOR = vOR;
		this.eR = eR;
	}

	@Override
	public int compare(Ratable o1, Ratable o2) {
		//RatingsAnalyzer.bayesianAverage(oR, eR, vOR)
		double a = RatingsAnalyzer.bayesianAverage(o1.getRatings(), eR, vOR);
		double b = RatingsAnalyzer.bayesianAverage(o2.getRatings(), eR, vOR);
		// TODO Auto-generated method stub

		if((b-a) > 0) {
			return 1;
		}

		if((b-a) < 0) {
			return -1;
		}

		return 0;
	}
}



